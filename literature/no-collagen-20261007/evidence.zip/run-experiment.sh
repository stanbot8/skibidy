#!/usr/bin/env bash
cd /mnt/d/dev/skibidy
source /root/biodynamo-v1.05.169/bin/thisbdm.sh >/dev/null 2>&1
set -euo pipefail
export OMP_NUM_THREADS=1 OMP_DYNAMIC=FALSE
.git/analysis-venv/bin/python scripts/run_replicates.py --matrix --n 3 --out-dir batch/results/no-collagen-20261007-clean >.git/no-cohorts-clean.log 2>&1
.git/analysis-venv/bin/python .git/no-diagnostic.py >.git/no-diagnostic.log 2>&1
.git/analysis-venv/bin/python .git/no-export.py >.git/no-export.log 2>&1
