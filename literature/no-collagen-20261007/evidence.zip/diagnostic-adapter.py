"""Experiment adapter: keep the maintained runner and its receipts unchanged."""
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from scripts import run_replicates

setup = run_replicates.lib.setup_run

def setup_without_collagen_lysis(*args, **kwargs):
    setup(*args, **kwargs)
    run_replicates.lib.override_param("skin.mmp.collagen_degradation", 0)

run_replicates.lib.setup_run = setup_without_collagen_lysis
sys.argv = [str(root / "scripts/run_replicates.py"), "--n", "3",
            "--out-dir", "batch/results/no-collagen-20261007-mmp-off"]
run_replicates.main()
