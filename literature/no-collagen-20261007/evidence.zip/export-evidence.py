import csv
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tomllib
import zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root = Path.cwd()
dest = root / 'literature/no-collagen-20261007'
dest.mkdir(exist_ok=True)
base = '668708c4268a44f8f3bb3b3c484d436c110e1022'
arms = {'control': 'lactate-signal-20261007',
        'candidate': 'no-collagen-20261007-clean',
        'mmp-off-diagnostic': 'no-collagen-20261007-mmp-off'}
paths = ['modules/fibroblast/fibroblast_behavior.h', 'src/infra/sim_param.h',
         'src/skibidy.cc', 'modules/nitric_oxide/config.toml',
         'modules/nitric_oxide/nitric_oxide_pde.h', 'tests/fibroblast_test.cc']
sha = lambda data: hashlib.sha256(data).hexdigest()
receipt = {'base': base, 'source_sha256': {p: sha((root/p).read_bytes()) for p in paths},
           'runs': [], 'artifacts': {}}
entries = {}
summary = []
normal = {}
def flatten(value, prefix=''):
    result = {}
    for key, item in value.items():
        name = prefix + key
        if isinstance(item, dict):
            result.update(flatten(item, name + '.'))
        else:
            result[name] = item
    return result

for arm, directory in arms.items():
    folder = root / 'batch/results' / directory
    runtime = json.loads((folder/'runtime.json').read_text())
    if arm != 'control':
        assert runtime['binary_sha256'] == sha((root/'build/skibidy').read_bytes())
        library = [d for d in runtime['dependencies'] if Path(d['path']).name == 'libskibidy.so']
        assert len(library) == 1 and library[0]['sha256'] == sha((root/'build/libskibidy.so').read_bytes())
    entries[f'{arm}/runtime.json'] = (folder/'runtime.json').read_bytes()
    files = sorted(folder.glob('*/seed*/skibidy/metrics.csv'))
    assert len(files) == (3 if arm == 'mmp-off-diagnostic' else 9)
    for metric in files:
        run = metric.parent.parent
        cohort = run.parent.name
        seed = int(run.name[4:])
        config = flatten(tomllib.loads((run/'bdm.toml').read_text()))
        reference = root / 'batch/results' / arms['control'] / cohort / run.name / 'bdm.toml'
        control_config = flatten(tomllib.loads(reference.read_text()))
        differences = {k: [control_config.get(k), config.get(k)] for k in set(control_config)|set(config)
                       if control_config.get(k) != config.get(k)}
        allowed = {'simulation.output_dir', 'skin.nitric_oxide.collagen_suppression'}
        if arm == 'mmp-off-diagnostic':
            allowed.add('skin.mmp.collagen_degradation')
            assert config['skin.mmp.collagen_degradation'] == 0
        assert set(differences) <= allowed, differences
        rows = list(csv.DictReader(metric.open()))
        run_receipt = json.loads((run/'receipt.json').read_text())
        assert len(rows) == run_receipt['rows'] and rows
        assert all(math.isfinite(float(v)) for r in rows for v in r.values())
        assert float(rows[-1]['time_h']) == run_receipt['final_hours']
        assert run_receipt['final_hours'] >= config['skin.duration_days'] * 24 - config.get('skin.metrics_interval_h', 10) - 1e-6
        collagen = [float(r['mean_collagen_wound']) for r in rows]
        record = {'arm': arm, 'cohort': cohort, 'seed': seed,
                  'final_hours': run_receipt['final_hours'], 'validation_exit': run_receipt['validation_exit'],
                  'peak_collagen': max(collagen), 'final_collagen': collagen[-1]}
        summary.append(record)
        receipt['runs'].append({**record, 'config_differences': differences})
        if cohort == 'normal-wound':
            normal.setdefault(arm, []).append(([float(r['time_h'])/24 for r in rows], collagen))
        for f in sorted(run.rglob('*')):
            if f.is_file() and f.name in {'bdm.toml', 'run-config.toml', 'receipt.json', 'metrics.csv',
                                         'stdout.log', 'stderr.log', 'validation.txt', 'validation.json'}:
                entries[f'{arm}/{cohort}/{run.name}/{f.relative_to(run).as_posix()}'] = f.read_bytes()

for log in ['no-baseline-build.log', 'no-baseline-test.log', 'no-candidate-build.log',
            'no-candidate-test.log', 'no-clean-build.log', 'no-candidate-test-resolved.log',
            'no-test-loader.log', 'no-cohorts.log', 'no-python.log', 'no-sources.log', 'no-data-quality.log']:
    entries[f'checks/{log}'] = (root/'.git'/log).read_bytes()
assert b'1 FAILED TEST' in entries['checks/no-baseline-test.log']
assert b'[  PASSED  ] 175 tests.' in entries['checks/no-candidate-test-resolved.log']
assert b'[  FAILED  ]' not in entries['checks/no-candidate-test-resolved.log']
entries['diagnostic-adapter.py'] = (root/'.git/no-diagnostic.py').read_bytes()
entries['export-evidence.py'] = Path(__file__).read_bytes()
entries['run-experiment.sh'] = (root/'.git/no-runs.sh').read_bytes()
git = '/mnt/c/Program Files/Git/cmd/git.exe'
entries['implementation.patch'] = subprocess.check_output([git, 'diff', '--no-ext-diff', '--unified=0', base, '--', *paths])
with (dest/'summary.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(summary[0]))
    writer.writeheader()
    writer.writerows(summary)
fig, ax = plt.subplots(figsize=(8, 4.5))
for arm, runs in normal.items():
    values = np.array([y for x, y in runs])
    ax.plot(runs[0][0], np.median(values, axis=0), label=arm)
    ax.fill_between(runs[0][0], values.min(axis=0), values.max(axis=0), alpha=.15)
ax.set(xlabel='Days since injury', ylabel='Mean wound collagen (model units)',
       title='Normal wound, seeds 42–44: median and full range')
ax.set_yscale('symlog', linthresh=1e-10)
ax.legend()
fig.tight_layout()
fig.savefig(dest/'collagen.png', dpi=180)
plt.close(fig)
with zipfile.ZipFile(dest/'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(entries.items()):
        z.writestr(name, data)
        receipt['artifacts'][name] = sha(data)
with zipfile.ZipFile(dest/'evidence.zip') as z:
    assert z.testzip() is None
    assert all(sha(z.read(n)) == d for n, d in receipt['artifacts'].items())
receipt['zip_sha256'] = sha((dest/'evidence.zip').read_bytes())
(dest/'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(summary, indent=2))
